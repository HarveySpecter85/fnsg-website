export default function PartnersPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Partners</h1>
            <p className="mt-4">Our strategic partners.</p>
        </div>
    )
}
