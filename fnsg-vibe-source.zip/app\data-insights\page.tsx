export default function DataInsightsPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Data & Insights</h1>
            <p className="mt-4">Data-driven staffing decisions.</p>
        </div>
    )
}
