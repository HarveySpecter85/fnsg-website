export default function CompanyPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Company</h1>
            <p className="mt-4">About us.</p>
        </div>
    )
}
