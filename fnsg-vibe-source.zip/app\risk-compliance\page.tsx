export default function RiskCompliancePage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Risk & Compliance</h1>
            <p className="mt-4">Stay compliant with our tools.</p>
        </div>
    )
}
