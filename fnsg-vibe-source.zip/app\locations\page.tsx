export default function LocationsPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Locations</h1>
            <p className="mt-4">Where we operate.</p>
        </div>
    )
}
