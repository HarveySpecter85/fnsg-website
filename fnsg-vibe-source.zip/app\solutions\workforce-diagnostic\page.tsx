import WorkforceDiagnosticForm from '../../components/workforce-diagnostic-form'

export default function WorkforceDiagnosticPage() {
    return (
        <main className="min-h-screen bg-slate-50 py-12">
            <WorkforceDiagnosticForm />
        </main>
    )
}
