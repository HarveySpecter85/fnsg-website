export default function SolutionsPage() {
    return (
        <div className="p-10">
            <h1 className="text-3xl font-bold">Solutions</h1>
            <p className="mt-4">Explore our workforce solutions.</p>
        </div>
    )
}
